package pl.bk20.forest.trees

data class ForestState(
    val treeCount: Int
)